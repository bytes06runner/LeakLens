

def __phi__(phi_0, phi_1):
    if phi_0:
        return phi_0
    return phi_1

def set_field_wrapper(base, attr, value):
    setattr(base, attr, value)
    return base

def set_index_wrapper(base, attr, value):
    setattr(base, attr, value)
    return base

def global_wrapper(x):
    return x
import numpy as np
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
_var0 = np.random
_var1 = 0
rng = _var0.default_rng(_var1)
_var2 = 500
_var3 = 5
_var4 = (_var2, _var3)
X = rng.normal(size=_var4)
_var5 = 0
_var6 = X[:, _var5]
_var7 = 500
_var8 = rng.normal(size=_var7)
_var9 = (_var6 + _var8)
_var10 = 0
_var11 = (_var9 > _var10)
y = _var11.astype(int)
_var12 = StandardScaler()
X_0 = _var12.fit_transform(X)
_var17 = 0.2
_var18 = 0
(_var13, _var14, _var15, _var16) = train_test_split(X_0, y, test_size=_var17, random_state=_var18)
X_train = _var13
X_test = _var14
y_train = _var15
y_test = _var16
_var19 = LogisticRegression()
clf = _var19.fit(X_train, y_train)
_var19_0 = clf
_var20 = 'accuracy'
_var21 = clf.score(X_test, y_test)
print(_var20, _var21)
