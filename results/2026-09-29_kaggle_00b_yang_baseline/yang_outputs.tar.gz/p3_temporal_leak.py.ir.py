

def __phi__(phi_0, phi_1):
    if phi_0:
        return phi_0
    return phi_1

def set_field_wrapper(base, attr, value):
    setattr(base, attr, value)
    return base

def set_index_wrapper(base, attr, value):
    setattr(base, attr, value)
    return base

def global_wrapper(x):
    return x
import numpy as np
import pandas as pd
from sklearn.linear_model import Ridge
from sklearn.model_selection import train_test_split
_var0 = np.random
_var1 = 0
rng = _var0.default_rng(_var1)
_var2 = '2020-01-01'
_var3 = 730
_var4 = 'D'
_var5 = pd.date_range(_var2, periods=_var3, freq=_var4)
_var6 = {'date': _var5}
df = pd.DataFrame(_var6)
_var7 = 'value'
_var8 = len(df)
_var9 = rng.normal(size=_var8)
_var10 = np.cumsum(_var9)
df_0 = set_index_wrapper(df, _var7, _var10)
_var11 = 'lag1'
_var12 = 'value'
_var13 = df_0[_var12]
_var14 = 1
_var15 = _var13.shift(_var14)
df_1 = set_index_wrapper(df_0, _var11, _var15)
_var16 = 'target'
_var17 = 'value'
_var18 = df_1[_var17]
_var19 = (- 1)
_var20 = _var18.shift(_var19)
df_2 = set_index_wrapper(df_1, _var16, _var20)
df_3 = df_2.dropna()
_var21 = ['value', 'lag1']
X = df_3[_var21]
_var22 = 'target'
y = df_3[_var22]
_var27 = 0.2
_var28 = True
_var29 = 0
(_var23, _var24, _var25, _var26) = train_test_split(X, y, test_size=_var27, shuffle=_var28, random_state=_var29)
X_train = _var23
X_test = _var24
y_train = _var25
y_test = _var26
_var30 = Ridge()
model = _var30.fit(X_train, y_train)
_var30_0 = model
_var31 = 'r2'
_var32 = model.score(X_test, y_test)
print(_var31, _var32)
