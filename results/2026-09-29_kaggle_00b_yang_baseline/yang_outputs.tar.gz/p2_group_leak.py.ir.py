

def __phi__(phi_0, phi_1):
    if phi_0:
        return phi_0
    return phi_1

def set_field_wrapper(base, attr, value):
    setattr(base, attr, value)
    return base

def set_index_wrapper(base, attr, value):
    setattr(base, attr, value)
    return base

def global_wrapper(x):
    return x
import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
_var0 = np.random
_var1 = 0
rng = _var0.default_rng(_var1)
_var2 = 40
_var3 = 25
n_patients = _var2
per_patient = _var3
_var4 = np.arange(n_patients)
_var5 = np.repeat(_var4, per_patient)
_var6 = {'patient_id': _var5}
df = pd.DataFrame(_var6)
_var7 = rng.normal(size=n_patients)
_var8 = 'patient_id'
_var9 = df[_var8]
offset = _var7[_var9]
_var10 = 'f1'
_var11 = 0.3
_var12 = len(df)
_var13 = rng.normal(scale=_var11, size=_var12)
_var14 = (offset + _var13)
df_0 = set_index_wrapper(df, _var10, _var14)
_var15 = 'f2'
_var16 = len(df_0)
_var17 = rng.normal(size=_var16)
df_1 = set_index_wrapper(df_0, _var15, _var17)
_var18 = 'label'
_var19 = 0
_var20 = (offset > _var19)
_var21 = _var20.astype(int)
df_2 = set_index_wrapper(df_1, _var18, _var21)
_var22 = ['f1', 'f2']
X = df_2[_var22]
_var23 = 'label'
y = df_2[_var23]
_var28 = 0.2
_var29 = 0
(_var24, _var25, _var26, _var27) = train_test_split(X, y, test_size=_var28, random_state=_var29)
X_train = _var24
X_test = _var25
y_train = _var26
y_test = _var27
_var30 = 0
_var31 = RandomForestClassifier(random_state=_var30)
model = _var31.fit(X_train, y_train)
_var31_0 = model
_var32 = 'accuracy'
_var33 = model.score(X_test, y_test)
print(_var32, _var33)
